from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

admin.site.site_header = "Find-IT administration"
admin.site.site_title = "Find-IT"
admin.site.index_title = "Manage campus lost and found"

urlpatterns = [
    path("django-admin/", admin.site.urls),
    path("", include("core.urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
